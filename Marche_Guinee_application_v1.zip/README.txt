# Marché Guinée — première version connectée à Supabase

## Fichiers
- `index.html` : application web responsive et installable (PWA)
- `manifest.webmanifest` : nom et configuration d'installation
- `sw.js` : cache de base pour le chargement hors ligne de l'interface
- `icon.svg` : icône de l'application

## Publication
1. Dans le dépôt GitHub `marche-guinee`, téléversez ces 4 fichiers à la racine (remplacez l'ancien `index.html` si demandé).
2. Vérifiez que GitHub Pages publie la branche et le dossier racine.
3. Ouvrez l'adresse GitHub Pages dans Chrome sur Android, puis menu ⋮ > Ajouter à l'écran d'accueil / Installer.

## Configuration Supabase
Le projet utilise l'URL du projet et la clé `sb_publishable_...` (clé publique prévue pour le navigateur).
Ne mettez jamais une clé `secret` ou `service_role` dans le code client.

## Fonctions incluses
- inscription et connexion par e-mail
- affichage et recherche d'annonces
- filtre par catégorie
- publication d'annonce avec photo
- favoris
- ouverture de conversations et envoi de messages

Cette version est un premier socle. Les règles SQL, l'authentification par e-mail et les politiques de stockage doivent être testées avant une ouverture au public. Les notifications, modération, signalements, vérification vendeurs et paiement ne sont pas inclus.
